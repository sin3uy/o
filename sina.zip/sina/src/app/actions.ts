"use server";

import {
  analyzeUploadedImage,
  type AnalyzeUploadedImageInput,
  type AnalyzeUploadedImageOutput,
} from "@/ai/flows/analyze-uploaded-image";

export async function handleImageAnalysis(
  input: AnalyzeUploadedImageInput
): Promise<AnalyzeUploadedImageOutput> {
  try {
    const result = await analyzeUploadedImage(input);
    return result;
  } catch (error) {
    console.error("Error analyzing image:", error);
    throw new Error("Failed to analyze image with AI. Please try again.");
  }
}
