'use server';

/**
 * @fileOverview Image analysis flow that identifies the product in an uploaded image and generates a description in Arabic.
 *
 * - analyzeUploadedImage - Analyzes an uploaded image to identify the product and generate a description.
 * - AnalyzeUploadedImageInput - The input type for the analyzeUploadedImage function.
 * - AnalyzeUploadedImageOutput - The return type for the analyzeUploadedImage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeUploadedImageInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of a product, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type AnalyzeUploadedImageInput = z.infer<typeof AnalyzeUploadedImageInputSchema>;

const AnalyzeUploadedImageOutputSchema = z.object({
  productName: z.string().describe('The SEO-friendly, short name of the identified product in Arabic.'),
  productDescription: z.string().describe('The 100% SEO-friendly, medium-length description of the identified product in Arabic.'),
});
export type AnalyzeUploadedImageOutput = z.infer<typeof AnalyzeUploadedImageOutputSchema>;

export async function analyzeUploadedImage(input: AnalyzeUploadedImageInput): Promise<AnalyzeUploadedImageOutput> {
  return analyzeUploadedImageFlow(input);
}

const analyzeUploadedImagePrompt = ai.definePrompt({
  name: 'analyzeUploadedImagePrompt',
  input: {schema: AnalyzeUploadedImageInputSchema},
  output: {schema: AnalyzeUploadedImageOutputSchema},
  prompt: `مهمتك هي تحليل صورة المنتج المقدمة وإنشاء اسم ووصف للمنتج باللغة العربية، مع مراعاة تحسين محركات البحث (SEO) بشكل كامل.

- **اسم المنتج:** يجب أن يكون قصيراً وجذاباً ومتوافقاً مع السيو. لا تجعله طويلاً جداً.
- **وصف المنتج:** يجب أن يكون وصفاً تفصيلياً متوسط الطول، ليس طويلاً جداً وليس قصيراً جداً. يجب أن يكون متوافقاً مع السيو بنسبة 100% ويحتوي على كلمات مفتاحية ذات صلة بالمنتج.

Image: {{media url=photoDataUri}}`,
});

const analyzeUploadedImageFlow = ai.defineFlow(
  {
    name: 'analyzeUploadedImageFlow',
    inputSchema: AnalyzeUploadedImageInputSchema,
    outputSchema: AnalyzeUploadedImageOutputSchema,
  },
  async input => {
    const {output} = await analyzeUploadedImagePrompt(input);
    return output!;
  }
);
