'use server';

/**
 * @fileOverview Extracts the product name from an image using Google Gemini.
 *
 * - extractProductName - A function that extracts the product name from an image.
 * - ExtractProductNameInput - The input type for the extractProductName function.
 * - ExtractProductNameOutput - The return type for the extractProductName function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExtractProductNameInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of a product, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type ExtractProductNameInput = z.infer<typeof ExtractProductNameInputSchema>;

const ExtractProductNameOutputSchema = z.object({
  productName: z.string().describe('The name of the product identified in the image.'),
});
export type ExtractProductNameOutput = z.infer<typeof ExtractProductNameOutputSchema>;

export async function extractProductName(input: ExtractProductNameInput): Promise<ExtractProductNameOutput> {
  return extractProductNameFlow(input);
}

const prompt = ai.definePrompt({
  name: 'extractProductNamePrompt',
  input: {schema: ExtractProductNameInputSchema},
  output: {schema: ExtractProductNameOutputSchema},
  prompt: `You are an expert product identifier.  Given an image of a product, identify the name of the product.

  Here is the image:

  {{media url=photoDataUri}}
  `,
});

const extractProductNameFlow = ai.defineFlow(
  {
    name: 'extractProductNameFlow',
    inputSchema: ExtractProductNameInputSchema,
    outputSchema: ExtractProductNameOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
