import { config } from 'dotenv';
config();

import '@/ai/flows/extract-product-name.ts';
import '@/ai/flows/analyze-uploaded-image.ts';
import '@/ai/flows/generate-product-description.ts';