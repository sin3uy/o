"use client";

import { useState } from "react";
import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Bot, Image as ImageIcon, AlertCircle, Sparkles, Wand2, Loader2 } from "lucide-react";
import { handleImageAnalysis } from "@/app/actions";
import { useToast } from "@/hooks/use-toast";

type AnalysisResult = {
  productName: string;
  productDescription: string;
};

export function ProductDetective() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setResult(null);
      setError(null);
    }
  };

  const onAnalyze = async () => {
    if (!imagePreview) {
      toast({
        title: "لم يتم اختيار صورة",
        description: "الرجاء رفع صورة لتحليلها.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const analysisResult = await handleImageAnalysis({ photoDataUri: imagePreview });
      if (analysisResult && analysisResult.productName) {
        setResult(analysisResult);
      } else {
        throw new Error("لم يتم التعرف على المنتج في الصورة. قد لا يتمكن الذكاء الاصطناعي من التعرّف على هذا الكائن كمنتج.");
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "حدث خطأ غير معروف.";
      setError(errorMessage);
      toast({
        title: "فشل التحليل",
        description: "تعذر تحليل الصورة. الرجاء تجربة صورة أخرى أو منتج مختلف.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto">
      <Card className="overflow-hidden shadow-2xl shadow-primary/10">
        <CardHeader className="text-center border-b bg-card/80 backdrop-blur-sm">
          <div className="flex items-center justify-center gap-3">
            <Wand2 className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-extrabold font-headline tracking-tight">
              كاشف المنتجات
            </h1>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="grid md:grid-cols-2">
            <div className="p-6 md:p-8 flex flex-col gap-6 border-b md:border-b-0 md:border-l">
              <div className="space-y-1">
                <h3 className="text-xl font-semibold font-headline">رفع صورة</h3>
                <p className="text-muted-foreground">اختر صورة لمنتج للبدء.</p>
              </div>

              <div className="space-y-4">
                <Label htmlFor="picture" className="sr-only">صورة المنتج</Label>
                <Input id="picture" type="file" accept="image/*" onChange={handleFileChange} className="file:text-primary-foreground file:bg-primary hover:file:bg-primary/90 file:font-semibold file:rounded-md file:ml-4 file:px-4 file:h-10 file:border-none cursor-pointer" />
              </div>

              <div className="aspect-video w-full rounded-lg border-2 border-dashed bg-muted/30 flex items-center justify-center overflow-hidden">
                {imagePreview ? (
                  <Image src={imagePreview} alt="معاينة المنتج" width={600} height={400} className="object-contain h-full w-full" />
                ) : (
                  <div className="text-center text-muted-foreground p-4">
                    <ImageIcon className="mx-auto h-12 w-12" />
                    <p className="mt-2 text-sm font-medium">ستظهر معاينة الصورة هنا</p>
                  </div>
                )}
              </div>

              <Button onClick={onAnalyze} disabled={!imagePreview || loading} className="w-full font-bold text-base" size="lg">
                {loading ? (
                  <>
                    <Loader2 className="ml-2 h-5 w-5 animate-spin" />
                    جاري التحليل...
                  </>
                ) : (
                  <>
                    <Sparkles className="ml-2 h-5 w-5" />
                    تحليل الصورة
                  </>
                )}
              </Button>
            </div>
            
            <div className="p-6 md:p-8 flex flex-col gap-6 bg-muted/20">
              <div className="space-y-1">
                <h3 className="text-xl font-semibold font-headline">نتائج التحليل</h3>
                <p className="text-muted-foreground">سيظهر اسم المنتج ووصفه أدناه.</p>
              </div>

              <div className="flex-grow">
                {loading ? (
                  <div className="space-y-6 pt-2">
                    <div className="space-y-2">
                      <Skeleton className="h-5 w-1/3" />
                      <Skeleton className="h-8 w-3/4" />
                    </div>
                     <div className="space-y-2">
                      <Skeleton className="h-5 w-1/3" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-5/6" />
                    </div>
                  </div>
                ) : error ? (
                  <div className="flex flex-col items-center justify-center text-center h-full rounded-lg bg-destructive/10 p-8 text-destructive">
                    <AlertCircle className="h-12 w-12 mb-4" />
                    <p className="text-lg font-bold">خطأ في التحليل</p>
                    <p className="text-sm max-w-sm">{error}</p>
                  </div>
                ) : result ? (
                  <div className="space-y-6 animate-in fade-in-50 duration-500">
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">اسم المنتج</Label>
                      <p className="text-2xl font-bold font-headline text-primary">{result.productName}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">وصف المنتج</Label>
                      <p className="text-base text-foreground/90 whitespace-pre-wrap leading-relaxed">{result.productDescription}</p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center text-center text-muted-foreground h-full rounded-lg bg-muted/50 p-8">
                    <Bot className="h-16 w-16 mb-4" />
                    <p className="text-lg font-medium">نتائجك في انتظارك</p>
                    <p className="text-sm">ارفع صورة وانقر على "تحليل" لترى السحر!</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
