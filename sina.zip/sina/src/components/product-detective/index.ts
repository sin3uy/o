export * from './product-detective';
