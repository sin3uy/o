# **App Name**: Product Detective

## Core Features:

- Image Upload: Allow users to upload an image of a product.
- Image Analysis: Use Google Gemini to analyze the uploaded image.
- Product Identification: Extract the product name from the analyzed image using Google Gemini.
- Product Description: Generate a product description based on the image analysis using Google Gemini as a tool.
- Result Display: Display the product name and description to the user.

## Style Guidelines:

- Primary color: Soft blue (#77B5FE) to convey trust and clarity, reflecting the app's analytical purpose.
- Background color: Light gray (#F0F4F8), nearly white, for a clean and professional look.
- Accent color: Muted purple (#A982FF) for interactive elements.
- Body and headline font: 'Inter', a sans-serif font for a modern and readable interface.
- Use clear and concise icons to represent different functions and categories.
- Simple and intuitive layout with a clear separation of image upload, analysis, and results display areas.
- Subtle loading animations during image analysis to provide feedback to the user.